from flask import Flask, request, jsonify
import os
from scrape_bank import WebBrowse
import gunicorn

app = Flask(__name__)

@app.route('/scrape', methods=['POST'])
def scrape():
    data = request.json
    credentials = data.get('credentials')
    mode = data.get('mode', 'add')

    browse = WebBrowse()
    creds = browse.doAccountList([None, credentials])

    if creds:
        return jsonify({"status": "success", "message": "Data berhasil disinkronkan"}), 200
    else:
        return jsonify({"status": "error", "message": "Gagal membaca kredensial"}), 400

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=int(os.environ.get("PORT", 10000)))